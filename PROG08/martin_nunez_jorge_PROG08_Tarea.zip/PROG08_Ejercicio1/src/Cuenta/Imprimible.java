package Cuenta;

//Creamos la interfaz imprimible con el metodo devolverInfoString
public interface Imprimible {

    public String devolverInfoString();
}
